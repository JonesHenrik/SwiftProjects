//
//  ContentView.swift
//  SampleSample
//
//  Created by Henrik Jones on 2/5/25.
//
import SwiftUI

struct FirstView: View {
    @Bindable var vm: NavigationHubViewModel
    
    var body: some View {
        ZStack {
            Color.green
            Text("You pushed")
        }
    }
}

#Preview {
    FirstView(vm: NavigationHubViewModel())
}
