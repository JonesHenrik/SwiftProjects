//
//  SampleSampleApp.swift
//  SampleSample
//
//  Created by Henrik Jones on 2/5/25.
//

import SwiftUI

@main
struct SampleSampleApp: App {
    var body: some Scene {
        WindowGroup {
            NavigationHub()
        }
    }
}
