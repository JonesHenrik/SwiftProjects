//
//  NewView.swift
//  SampleSample
//
//  Created by Henrik Jones on 2/5/25.
//

import SwiftUI

struct SecondView: View {
    @Bindable var vm: NavigationHubViewModel
    
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

#Preview {
    SecondView(vm: NavigationHubViewModel())
}
