//
//  NavigationHub.swift
//  SampleSample
//
//  Created by Henrik Jones on 2/5/25.
//

import SwiftUI

@Observable
class NavigationHubViewModel {
    var currentView: sampleViews = .contentView
    
    enum sampleViews {
        case contentView
        case newView
        case thirdView
    }
}


struct NavigationHub: View {
    @State var vm = NavigationHubViewModel()
    
    var body: some View {
        ZStack {
            switch vm.currentView {
            case .contentView:
                FirstView(vm: vm)
            case .newView:
                SecondView(vm: vm)
            case .thirdView:
                ThirdView(vm: vm)
            }
        }
    }
}


#Preview {
    NavigationHub()
}
