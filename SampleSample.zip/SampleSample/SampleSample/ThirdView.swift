//
//  ThirdView.swift
//  SampleSample
//
//  Created by Henrik Jones on 2/5/25.
//

import SwiftUI

struct ThirdView: View {
    @Bindable var vm: NavigationHubViewModel
    
    var body: some View {
        Button("New view time") { }
    }
}

#Preview {
    ThirdView(vm: NavigationHubViewModel())
}
